# Microsoft Fabric Dataflows Gen2 Tutorial Backup

Date: 2026-09-16
Workspace: MS Learn Dataflows Gen2
Lakehouse: MyDataLake
Dataflow: Dataflow 1
Pipeline: Load Data
Lakehouse table: dbo.orders

## Completed workflow

Public GitHub CSV
    -> Dataflow 1
    -> Power Query transformation
    -> MonthNo column
    -> MyDataLake / dbo.orders
    -> Load Data pipeline
    -> Dataflow 1 execution
    -> successful Lakehouse refresh

## Verification

The completed Lakehouse table showed:
- 542 rows
- 8 columns
- MonthNo present
- Pipeline activity Dataflow1: Succeeded
- Pipeline status: Succeeded

## Source

The tutorial source file was:
https://raw.githubusercontent.com/MicrosoftLearning/dp-data/main/orders.csv

Microsoft Learn tutorial:
https://microsoftlearning.github.io/mslearn-fabric/Instructions/Labs/05-dataflows-gen2.html

## Important note

This package preserves the completed configuration/documentation and screenshots.
The source CSV is a public Microsoft Learning file and is referenced above.
For a fully self-contained data backup, export the `dbo.orders` table from the Fabric Lakehouse as CSV/Parquet before deleting the Fabric resources.

## Rebuild summary

1. Create a Fabric Trial workspace named `MS Learn Dataflows Gen2`.
2. Create Lakehouse `MyDataLake` with schemas enabled.
3. Create Dataflow Gen2 `Dataflow 1`.
4. Load the public `orders.csv` source.
5. Add custom column:
   - Name: MonthNo
   - Data type: Whole number
   - Formula: Date.Month([OrderDate])
6. Use `MyDataLake` as the Lakehouse destination and create `orders`.
7. Save & run the Dataflow.
8. Create Pipeline `Load Data`.
9. Add a Dataflow activity using `Dataflow 1`.
10. Save and run the pipeline.
