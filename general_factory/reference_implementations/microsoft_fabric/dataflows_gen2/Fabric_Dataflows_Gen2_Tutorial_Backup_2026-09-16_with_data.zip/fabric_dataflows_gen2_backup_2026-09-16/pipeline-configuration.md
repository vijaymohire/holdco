# Load Data - Pipeline Configuration Backup

## Pipeline
Name: Load Data

## Activity
Activity type: Dataflow
Activity name: Dataflow1

## Configuration
Workspace: MS Learn Dataflows Gen2
Dataflow: Dataflow 1

## Execution result
Pipeline status: Succeeded
Dataflow1 activity status: Succeeded
Observed run duration: 56 seconds

The successful run was followed by verification of MyDataLake / dbo / orders.
