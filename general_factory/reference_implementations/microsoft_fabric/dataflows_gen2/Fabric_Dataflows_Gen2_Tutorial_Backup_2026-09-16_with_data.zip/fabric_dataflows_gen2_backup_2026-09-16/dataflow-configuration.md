# Dataflow 1 - Configuration Backup

## Source
Type: Text/CSV
URL:
https://raw.githubusercontent.com/MicrosoftLearning/dp-data/main/orders.csv

Authentication: Anonymous
Gateway: None

## Query
Query name: orders

## Transformation
Custom column:
- Name: MonthNo
- Data type: Whole number
- Formula: Date.Month([OrderDate])

## Destination
Type: Lakehouse
Workspace: MS Learn Dataflows Gen2
Lakehouse: MyDataLake
Table: orders
Schema: dbo

## Result
The resulting table was verified in the Lakehouse with 542 rows and 8 columns.
