# Backup Manifest

## Files
- README.md
- dataflow-configuration.md
- pipeline-configuration.md
- source-data-reference.txt
- screenshots/01_orders_table_created.png
- screenshots/02_pipeline_created.png
- screenshots/03_pipeline_dataflow_configured.png
- screenshots/04_pipeline_run_succeeded.png
- screenshots/05_orders_table_verified.png

## Data status
The actual source data is not duplicated in this package because the original source is publicly available from Microsoft Learning. The source URL is recorded in source-data-reference.txt.

To make the backup fully self-contained, export the current dbo.orders table from Fabric before deleting the workspace.
